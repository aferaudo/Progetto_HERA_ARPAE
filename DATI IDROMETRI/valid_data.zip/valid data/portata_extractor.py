import pandas as pd
import os
import numpy as np
import pyodbc

file_list = os.listdir(".")
conn = pyodbc.connect('Driver={/opt/microsoft/msodbcsql17/lib64/libmsodbcsql-17.7.so.2.1};'
                      'Server=localhost;'
                      'Database=Hera;'
                      'UID=SA;'
                      'PWD=ServerVMHeraDB1*;')
cursor = conn.cursor()

query = "INSERT INTO dbo.IDROMETRI (data_ora, Portata, nome) values(?,?,?,?)"


for k, file_name in enumerate(file_list):
    if not file_name.endswith(".xlsx"):
        print("bad file format {}".format(file_name))
        continue
    
    print("Analysing file {} {}/{}".format(file_name, k+1, len(file_list)))

    value_sheet = pd.read_excel(file_name, sheet_name="Tabella dei dati")
    name_sheet = pd.read_excel(file_name, sheet_name="Tabella delle stazioni")
    
    # There are stations with multple sensors, in such a case we use the file name as station name
    if len(name_sheet) > 1:
        temp = name_sheet.head(1)
        nome = file_name.split("(")[0]
    else: 
        nome = name_sheet["Nome della stazione"].values[0]

    value_sheet_formatted = value_sheet.drop(labels=[0,1,2,3,4,5], axis=0, inplace=False)
    
    for index, row in value_sheet_formatted.iterrows():
        date = row["Unnamed: 0"]
        #print()
        if pd.isnull(row["Unnamed: 2"]):
            # print(date)
            portata = -99
        else:
            portata = float(row["Unnamed: 2"])

        # Write in DB
        cursor.execute(query, date, portata, nome)
    cursor.commit()



cursor.close()